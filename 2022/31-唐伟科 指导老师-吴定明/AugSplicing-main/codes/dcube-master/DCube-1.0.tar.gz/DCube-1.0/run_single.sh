# Program : run_single.sh
# Description : Run the serial version of the D-Cube algorithm

java -cp ./DCube-1.0.jar dcube.Proposed $@
