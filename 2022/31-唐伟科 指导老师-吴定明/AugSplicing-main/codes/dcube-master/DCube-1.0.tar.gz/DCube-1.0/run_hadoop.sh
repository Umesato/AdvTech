# Program : run_hadoop.sh
# Description : Run the Hadoop version of the D-Cube algorithm
hadoop jar DCube-1.0.jar dcube.hadoop.ProposedHadoop $@
